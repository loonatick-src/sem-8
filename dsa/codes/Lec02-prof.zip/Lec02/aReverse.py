def aReverse(S):
    """Assume we know how to reverse a problem of size len(S) -1."""
    if len(S) == 1:
        return S
    else:
        smaller = S[1:len(S)]
        Q = aReverse(smaller)
        Q.append(S[0])
        return Q
