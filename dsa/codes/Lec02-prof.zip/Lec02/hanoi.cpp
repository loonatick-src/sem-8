#include <iostream>
using namespace std;
void hanoi (int n,  char a, char b, char c){
  if (n == 1) cout << "move from " << a << " to " << b << endl;
  else {
    hanoi (n-1, a, c, b);
    cout << "move from " << a << " to " << b << endl;
    hanoi (n-1, c, b, a);
  }
}

int main() {
  int towerSize = 1;
  cin >> towerSize;
  hanoi (towerSize, 'x', 'y', 'z');
  return 0;
}
